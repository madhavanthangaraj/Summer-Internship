package com.example.springbootfirst.models;

import lombok.Data;

@Data
public class LoginDetails {
    private String userName;
    private String password;
}
